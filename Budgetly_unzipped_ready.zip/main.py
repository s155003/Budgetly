def main():
    print("Welcome to Budgetly!")
    budget = {}
    while True:
        category = input("Enter a budget category (or 'done' to finish): ")
        if category.lower() == 'done':
            break
        try:
            amount = float(input(f"Enter amount for {category}: "))
            budget[category] = amount
        except ValueError:
            print("Please enter a valid number.")
    
    print("\nYour budget summary:")
    total = sum(budget.values())
    for category, amount in budget.items():
        print(f"{category}: ${amount:.2f}")
    print(f"Total budget: ${total:.2f}")

if __name__ == "__main__":
    main()
