from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_login import UserMixin

db = SQLAlchemy()

followers = db.Table(
    'followers',
    db.Column('follower_id', db.Integer, db.ForeignKey('user.id')),
    db.Column('followed_id', db.Integer, db.ForeignKey('user.id'))
)

likes = db.Table(
    'likes',
    db.Column('user_id', db.Integer, db.ForeignKey('user.id')),
    db.Column('entry_id', db.Integer, db.ForeignKey('budget_entry.id'))
)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    posts = db.relationship('BudgetEntry', backref='author', lazy='dynamic')

    followers = db.relationship(
        'User', secondary=followers,
        primaryjoin=(followers.c.followed_id == id),
        secondaryjoin=(followers.c.follower_id == id),
        backref=db.backref('following', lazy='dynamic'),
        lazy='dynamic'
    )

    def follow(self, user):
        if not self.is_following(user):
            self.following.append(user)

    def unfollow(self, user):
        if self.is_following(user):
            self.following.remove(user)

    def is_following(self, user):
        return self.following.filter(followers.c.followed_id == user.id).count() > 0

    def like(self, entry):
        if not self.has_liked(entry):
            entry.likes.append(self)

    def unlike(self, entry):
        if self.has_liked(entry):
            entry.likes.remove(self)

    def has_liked(self, entry):
        return entry.likes.filter(likes.c.user_id == self.id).count() > 0

class BudgetEntry(db.Model):
    __tablename__ = 'budget_entry'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200))
    amount = db.Column(db.Float, default=0.0)
    category = db.Column(db.String(80), default='Misc')
    kind = db.Column(db.String(20), default='expense')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    likes = db.relationship('User', secondary=likes, backref=db.backref('liked_entries', lazy='dynamic'), lazy='dynamic')
