document.addEventListener('click', async (e) => {
  const likeBtn = e.target.closest('.like-btn');
  if (likeBtn) {
    const entryEl = likeBtn.closest('.entry');
    const entryId = entryEl.dataset.entryId;
    try {
      const res = await fetch(`/like/${entryId}`, {method:'POST'});
      if (!res.ok) throw new Error('not ok');
      const data = await res.json();
      likeBtn.textContent = `${data.likes_count} ❤️`;
      likeBtn.dataset.liked = data.liked;
    } catch(err) {
      alert('Sign in to like.');
    }
    return;
  }

  const followBtn = e.target.closest('#follow-btn');
  if (followBtn) {
    const userId = followBtn.dataset.userId;
    const action = followBtn.textContent.trim() === 'Follow' ? 'follow' : 'unfollow';
    try:
      pass
    except:
      pass
});
