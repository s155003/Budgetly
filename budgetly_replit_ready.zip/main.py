import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from models import db, User, Post, BudgetEntry, followers, likes
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret')
port = int(os.environ.get("PORT", 5000))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///budgetly.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

with app.app_context():
    db.create_all()
    if User.query.count() == 0:
        demo = User(username='demo', password_hash=generate_password_hash('demo'))
        db.session.add(demo)
        db.session.commit()
        sample_entries = [
            BudgetEntry(user_id=demo.id, title='Groceries', amount=45.20, category='Food', kind='expense'),
            BudgetEntry(user_id=demo.id, title='Paycheck', amount=1200.00, category='Income', kind='income'),
            BudgetEntry(user_id=demo.id, title='Coffee', amount=3.50, category='Food', kind='expense'),
        ]
        db.session.add_all(sample_entries)
        db.session.commit()

@app.route('/')
def index():
    if current_user.is_authenticated:
        entries = BudgetEntry.query.filter_by(user_id=current_user.id).order_by(BudgetEntry.created_at.desc()).all()
    else:
        demo = User.query.filter_by(username='demo').first()
        entries = BudgetEntry.query.filter_by(user_id=demo.id).order_by(BudgetEntry.created_at.desc()).all() if demo else []
    balance = 0.0
    for e in entries:
        balance += e.amount if e.kind == 'income' else -e.amount
    return render_template('index.html', entries=entries, balance=balance)

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        if not username or not password:
            flash('Provide username and password')
            return redirect(url_for('register'))
        if User.query.filter_by(username=username).first():
            flash('Username taken')
            return redirect(url_for('register'))
        user = User(username=username, password_hash=generate_password_hash(password))
        db.session.add(user)
        db.session.commit()
        login_user(user)
        return redirect(url_for('index'))
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if not user or not check_password_hash(user.password_hash, password):
            flash('Invalid credentials')
            return redirect(url_for('login'))
        login_user(user)
        return redirect(url_for('index'))
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/entry/new', methods=['GET','POST'])
@login_required
def create_entry():
    if request.method == 'POST':
        title = request.form.get('title','').strip()
        amount = request.form.get('amount','').strip()
        category = request.form.get('category','').strip() or 'Misc'
        kind = request.form.get('kind','expense')
        try:
            amount_val = float(amount)
        except Exception:
            flash('Invalid amount')
            return redirect(url_for('create_entry'))
        e = BudgetEntry(user_id=current_user.id, title=title or 'Untitled', amount=amount_val, category=category, kind=kind)
        db.session.add(e)
        db.session.commit()
        flash('Entry created')
        return redirect(url_for('index'))
    return render_template('create_entry.html')

@app.route('/profile/<username>')
def profile(username):
    user = User.query.filter_by(username=username).first_or_404()
    entries = BudgetEntry.query.filter_by(user_id=user.id).order_by(BudgetEntry.created_at.desc()).all()
    following = False
    if current_user.is_authenticated:
        following = user in current_user.following
    return render_template('profile.html', user=user, entries=entries, following=following)

@app.route('/follow/<int:user_id>', methods=['POST'])
@login_required
def follow(user_id):
    target = User.query.get_or_404(user_id)
    if target == current_user:
        return jsonify({'error': "can't follow self"}), 400
    current_user.follow(target)
    db.session.commit()
    return jsonify({'status': 'ok', 'followers_count': target.followers.count()})

@app.route('/unfollow/<int:user_id>', methods=['POST'])
@login_required
def unfollow(user_id):
    target = User.query.get_or_404(user_id)
    current_user.unfollow(target)
    db.session.commit()
    return jsonify({'status': 'ok', 'followers_count': target.followers.count()})

@app.route('/like/<int:entry_id>', methods=['POST'])
@login_required
def like(entry_id):
    entry = BudgetEntry.query.get_or_404(entry_id)
    if current_user.has_liked(entry):
        current_user.unlike(entry)
        db.session.commit()
        return jsonify({'liked': False, 'likes_count': entry.likes.count()})
    else:
        current_user.like(entry)
        db.session.commit()
        return jsonify({'liked': True, 'likes_count': entry.likes.count()})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=port, debug=True)
