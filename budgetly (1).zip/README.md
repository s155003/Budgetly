# Budgetly — financial literacy web app

## Run locally (Replit)
1. Create new Repl (Python).
2. Add files from this repo.
3. (Optional) Set SECRET_KEY in Replit secrets for security.
4. Click Run (or `python3 main.py`).
5. Open the web view and use the app.
